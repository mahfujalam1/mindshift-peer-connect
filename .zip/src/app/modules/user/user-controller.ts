/* eslint-disable @typescript-eslint/no-unused-vars */
import { UserServices } from "./user-service";
import catchAsync from "../../utilities/catchAsync";
import sendResponse from "../../utilities/sendResponse";
import httpStatus from "http-status";
import { getUploadedFileUrl } from "../../helper/multer-s3-uploader";
import AppError from "../../error/appError";
import userValidations from "./user-validation";

export const createUser = catchAsync(async (req, res, next) => {
  const userData = req.body;
  console.log('sign up', userData)

  const result = await UserServices.createUserIntoDB(userData);

  if (!result) {
    sendResponse(res, {
      statusCode: httpStatus.NOT_FOUND,
      success: false,
      message: "No Data Found",
    });
  }

  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: "User registered successfully",
    data: result,
  });
});


const verifyCode = catchAsync(async (req, res) => {
  const result = await UserServices.verifyCode(
    req?.body?.email,
    req?.body?.verifyCode
  );
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Email verified successfully. Waiting for admin approval',
    data: result,
  });
});



const resendVerifyCode = catchAsync(async (req, res) => {
  const result = await UserServices.resendVerifyCode(req?.body?.email);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Verify code send to your email inbox',
    data: result,
  });
});


const getMyProfile = catchAsync(async (req, res) => {
  const result = await UserServices.getMyProfile(req.user);

  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Successfully retrieved your data',
    data: result,
  });
});



const updateProfile = catchAsync(async (req, res) => {
  const { files } = req;
  let requestPayload = { ...req.body };

  if (typeof requestPayload.data === 'string') {
    try {
      const parsedData = JSON.parse(requestPayload.data);
      if (typeof parsedData === 'object' && parsedData !== null) {
        requestPayload = { ...requestPayload, ...parsedData };
        delete requestPayload.data;
      }
    } catch {
      throw new AppError(
        httpStatus.BAD_REQUEST,
        'Data field must be valid JSON'
      );
    }
  }

  // Parse location if it's sent as a string (common in form-data)
  if (typeof requestPayload.location === 'string') {
    try {
      requestPayload.location = JSON.parse(requestPayload.location);
    } catch {
      throw new AppError(
        httpStatus.BAD_REQUEST,
        'Location must be valid JSON'
      );
    }
  }

  // Parse expertise if it's sent as a JSON string or comma-separated string (common in form-data)
  if (typeof requestPayload.expertise === 'string') {
    const trimmed = requestPayload.expertise.trim();
    if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
      try {
        requestPayload.expertise = JSON.parse(trimmed);
      } catch {
        throw new AppError(
          httpStatus.BAD_REQUEST,
          'Expertise must be valid JSON array or ObjectId string'
        );
      }
    } else if (trimmed.includes(',')) {
      requestPayload.expertise = trimmed.split(',').map((id: string) => id.trim());
    }
  }

  // Multer parses multipart fields after the route-level middleware stage, so
  // validate the normalized form-data payload here.
  const { body: payload } =
    await userValidations.updateProfileValidationSchema.parseAsync({
      body: requestPayload,
    });

  let imageUrl;
  if (files && !Array.isArray(files)) {
    const profileImage = files.profileImage?.[0] || files.profile_image?.[0];
    imageUrl = getUploadedFileUrl(profileImage);
  }
  const token = req.user;
  const result = await UserServices.updateProfile(token?.id, imageUrl, payload);

  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Successfully update your profile',
    data: result,
  });
});



const blockUser = catchAsync(async (req, res) => {
  const { userId } = req.params;

  if (req.user.id === userId) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      'You cannot block your own account'
    );
  }

  const result = await UserServices.blockUser(
    req.user.id,
    userId,
    req.user.role
  );

  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: result.blocked
      ? 'Successfully blocked this User'
      : 'Successfully unblocked this User',
    data: result
  })
})


const getSingleUser = catchAsync(async (req, res) => {
  const result = await UserServices.getSingleUser(req.params.id, req.user.id);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'User retrieved successfully',
    data: result,
  });
});


const getAllUser = catchAsync(async (req, res) => {
  const result = await UserServices.getAllUser(req?.query);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'users retrieved successfully',
    data: result,
  });
});



const getMyReferralNetwork = catchAsync(async (req, res) => {
  const result = await UserServices.getMyReferralNetwork(
    req.user.id,
    req.query
  );
  console.log('getMyReferralNetwork result:', result);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'My Referral Network retrieved successfully',
    data: result,
  });
});

const getAddedMeToReferralNetwork = catchAsync(async (req, res) => {
  const result = await UserServices.getAddedMeToReferralNetwork(
    req.user.id,
    req.query
  );
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Added Me To Their Referral Network retrieved successfully',
    data: result,
  });
});

const addToReferralNetwork = catchAsync(async (req, res) => {
  const { targetUserId } = req.params;
  const result = await UserServices.addToReferralNetwork(req.user.id, targetUserId);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'User added to your referral network successfully',
    data: result,
  });
});

const removeFromMyReferralNetwork = catchAsync(async (req, res) => {
  console.log(req.params.targetUserId)
  const result = await UserServices.removeFromMyReferralNetwork(
    req.user.id,
    req.params.targetUserId
  );

  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'User removed from your referral network successfully',
    data: result,
  });
});

const getBrowsableUsersForReferral = catchAsync(async (req, res) => {
  const result = await UserServices.getBrowsableUsersForReferral(req.user.id, req.query);
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Users retrieved successfully',
    data: result,
  });
});

const registerDevice = catchAsync(async (req, res) => {
  const result = await UserServices.registerDevice(
    req.user.id,
    req.body.playerId
  );
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Device registered for push notifications',
    data: result,
  });
});

const unregisterDevice = catchAsync(async (req, res) => {
  const result = await UserServices.unregisterDevice(
    req.user.id,
    req.body.playerId
  );
  sendResponse(res, {
    statusCode: httpStatus.OK,
    success: true,
    message: 'Device unregistered from push notifications',
    data: result,
  });
});

export const UserControllers = {
  createUser,
  verifyCode,
  resendVerifyCode,
  getMyProfile,
  updateProfile,
  blockUser,
  getSingleUser,
  getAllUser,
  getMyReferralNetwork,
  getAddedMeToReferralNetwork,
  addToReferralNetwork,
  removeFromMyReferralNetwork,
  getBrowsableUsersForReferral,
  registerDevice,
  unregisterDevice,
};
