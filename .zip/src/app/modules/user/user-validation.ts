import { z } from "zod";
import { ENUM_USER_STATUS } from "../../utilities/enum";

const objectIdSchema = z.string().regex(/^[a-f\d]{24}$/i, {
  message: 'Invalid ObjectId',
});

// OneSignal subscription ids are UUIDs today, but the value is opaque to us.
// Validating the shape would only turn a client-side SDK change into a failed
// login, so we just require a non-empty string.
const playerIdSchema = z
  .string({ required_error: 'Device id is required' })
  .trim()
  .min(1, { message: 'Device id is required' });

// Define the schema
const UserValidationSchema = z.object({
  body: z.object({
    fullName: z.string().min(2, { message: 'full Name is required' }),
    email: z.string().email({ message: 'Invalid email format' }),
    password: z.string().min(6, { message: 'Password must be at least 6 characters long' }),
    profession: z.string({ required_error: 'Profession ID is required' }),
    licenseNo: z.string({ required_error: 'License Number is required' }),
    governingBody: z.string({ required_error: 'Governing Body ID is required' }),
    country: z.string({ required_error: 'Country is required' }),
    province: z
      .string({ required_error: 'Province is required' })
      .trim()
      .optional(),
    city: z.string({ required_error: 'City is required' }),
    playerId: playerIdSchema.optional(),
  }),
});


const updateProfileValidationSchema = z.object({
  body: z.object({
    fullName: z.string().min(2).max(100).optional(),
    profession: objectIdSchema.optional(),
    licenseNo: z.string().min(1).optional(),
    governingBody: objectIdSchema.optional(),
    expertise: z
      .preprocess((val) => {
        if (typeof val === 'string') {
          const trimmed = val.trim();
          if (trimmed.startsWith('[') || trimmed.startsWith('{')) {
            try {
              return JSON.parse(trimmed);
            } catch {
              return val;
            }
          }
          if (trimmed.includes(',')) {
            return trimmed.split(',').map((item) => item.trim());
          }
        }
        return val;
      }, z.union([z.array(objectIdSchema), objectIdSchema]))
      .optional(),
    phone: z.string().optional(),
    bio: z.string().optional(),
    country: z.string().min(1).optional(),
    province: z.string().trim().min(1).optional(),
    city: z.string().min(1).optional(),
    location: z.object({
      address: z.string().optional(),
      coordinates: z.tuple([z.number(), z.number()]).optional(),
      radiusInKm: z.number().nonnegative().optional(),
    }).strict().optional(),
  }).strict(),
});


const loginValidationSchema = z.object({
  body: z.object({
    email: z.string({ required_error: 'Email is required' }),
    password: z.string({ required_error: 'Password is required' }),
    playerId: playerIdSchema.optional(),
  }),
});


const changePasswordValidationSchema = z.object({
  body: z.object({
    oldPassword: z.string({ required_error: 'Old password is required' }),
    newPassword: z.string({ required_error: 'Password is required' }),
  }),
});


// refresh token validation schema -----------
const refreshTokenValidationSchema = z.object({
  cookies: z.object({
    refreshToken: z.string({ required_error: 'Refresh token is required' }),
  }),
});



// forget password validation schema
const forgetPasswordValidationSchema = z.object({
  body: z.object({
    email: z.string({ required_error: 'User email is required' }),
  }),
});


// reset password validation schema
const resetPasswordValidationSchema = z.object({
  body: z.object({
    email: z.string({ required_error: 'User email is required' }),
    newPassword: z.string({ required_error: 'New password is required' }),
  }),
});



const verifyCodeValidationSchema = z.object({
  body: z.object({
    email: z.string({ required_error: 'Email is required' }),
    verifyCode: z.number({ required_error: 'Phone number is required' }),
  }),
});

const resendVerifyCodeSchema = z.object({
  body: z.object({
    email: z.string({ required_error: 'Email is required' }),
  }),
});

const changeUserStatus = z.object({
  body: z.object({
    status: z.enum(
      Object.values(ENUM_USER_STATUS) as [string, ...string[]]
    ),
  }),
});

const deviceValidationSchema = z.object({
  body: z.object({
    playerId: playerIdSchema,
  }),
});

const deleteUserAccountValidationSchema = z.object({
  body: z.object({
    password: z.string({ required_error: 'Password is required' }),
  }),
});

const userValidations = {
  UserValidationSchema,
  loginValidationSchema,
  changePasswordValidationSchema,
  refreshTokenValidationSchema,
  forgetPasswordValidationSchema,
  resetPasswordValidationSchema,
  verifyCodeValidationSchema,
  resendVerifyCodeSchema,
  changeUserStatus,
  deleteUserAccountValidationSchema,
  updateProfileValidationSchema,
  deviceValidationSchema,
};

export default userValidations;
