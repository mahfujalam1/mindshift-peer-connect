import httpStatus from "http-status";
import { TUser, TUserRole } from "./user-interface";
import AppError from "../../error/appError";
import User from "./user-model";
import sendEmail from "../../utilities/sendEmail";
import registrationSuccessEmailBody from "../../mailTemplate/registerSucessEmail";
import { JwtPayload } from "jsonwebtoken";
import config from "../../config";
import { createToken } from "./user.utils";
import { PipelineStage, Types } from "mongoose";
import QueryBuilder from "../../builder/QueryBuilder";
import { Follow } from "../follow/follow.model";
import { Profession } from "../profession/profession.model";
import { GoverningBodyServices } from "../governingBody/governingBody.service";
import { GoverningBody } from "../governingBody/governingBody.model";
import { assertUsersCanInteract } from "./user-block.utils";
import Expertise from "../expertise/expertise.model";
import { Consult } from "../consult/consult.model";
import { ProfileViewServices } from "../profile-view/profile-view.service";
import {
  registerPushSubscription,
  unregisterPushSubscription,
} from "../../helper/pushSubscription";

const referralUserProjection = {
  _id: "$user._id",
  fullName: "$user.fullName",
  email: "$user.email",
  profileImage: "$user.profileImage",
  profession: {
    $ifNull: [
      { $arrayElemAt: ["$professionDetails.name", 0] },
      "$user.profession",
    ],
  },
  licenseNo: "$user.licenseNo",
  governingBody: "$user.governingBody",
  phone: "$user.phone",
  bio: "$user.bio",
  country: "$user.country",
  city: "$user.city",
  location: "$user.location",
  isPremium: "$user.isPremium",
  expertise: {
    $map: {
      input: "$expertiseDetails",
      as: "expertise",
      in: {
        _id: "$$expertise._id",
        name: "$$expertise.name",
        icon: "$$expertise.icon",
      },
    },
  },
};

const generateVerifyCode = (): number => {
  return Math.floor(100000 + Math.random() * 900000);
};

const createUserIntoDB = async (payload: TUser & { playerId?: string }) => {
  const emailExist = await User.findOne({ email: payload.email });
  if (emailExist) {
    throw new AppError(httpStatus.BAD_REQUEST, "This email already exists");
  }

  const profession = await Profession.findById(payload.profession);
  if (!profession) {
    throw new AppError(httpStatus.NOT_FOUND, "Profession not found");
  }

  await GoverningBodyServices.validateGoverningBodyInProfession(
    String(payload.governingBody),
    String(payload.profession)
  );

  const verifyCode = generateVerifyCode();

  const userDataPayload: Partial<TUser> = {
    email: payload.email,
    fullName: payload.fullName,
    password: payload.password,
    profession: payload.profession,
    licenseNo: payload.licenseNo,
    governingBody: payload.governingBody,
    country: payload.country,
    province: payload.province?.trim(),
    city: payload.city,
    verifyCode,
    codeExpireIn: new Date(Date.now() + 5 * 60000),
    ...(payload.role === "admin" ? { isVerified: true, isActive: true } : {}),
  };

  sendEmail({
    email: payload.email,
    subject: "Activate Your Account",
    html: registrationSuccessEmailBody(payload.fullName, verifyCode),
  });

  const user = await User.create(userDataPayload);

  // Registered through the shared helper so the device is detached from any
  // account that used it before.
  await registerPushSubscription(String(user._id), payload.playerId);

  return user;
};

const verifyCode = async (email: string, verifyCode: number) => {
  const user = await User.findOne({ email: email });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }
  if (user.codeExpireIn < new Date(Date.now())) {
    throw new AppError(httpStatus.BAD_REQUEST, "Verify code is expired");
  }
  if (verifyCode !== user.verifyCode) {
    throw new AppError(httpStatus.BAD_REQUEST, "Code doesn't match");
  }

  // Email is verified here, but the account remains pending admin approval.
  const result = await User.findOneAndUpdate(
    { email: email },
    { isActive: true },
    { new: true, runValidators: true }
  );

  if (!result) {
    throw new AppError(
      httpStatus.SERVICE_UNAVAILABLE,
      "Server temporary unable please try again letter"
    );
  }

  const tokenPayload = {
    id: String(result._id),
    email: result.email,
    role: result.role,
    scope: 'profile-setup' as const,
  };

  return {
    email,
    accessToken: createToken(
      tokenPayload,
      config.jwt_access_screet as string,
      config.jwt_access_expires_in
    ),
    refreshToken: createToken(
      tokenPayload,
      config.jwt_access_screet as string,
      config.jwt_access_expires_in
    ),
    waitingForAdminApproval: true,
    message: "Waiting for admin approval",
  };
};

const resendVerifyCode = async (email: string) => {
  const user = await User.findOne({ email: email });

  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }
  const verifyCode = generateVerifyCode();
  const updateUser = await User.findOneAndUpdate(
    { email: email },
    {
      verifyCode: verifyCode,
      codeExpireIn: new Date(Date.now() + 5 * 60000),
    },
    { new: true, runValidators: true }
  );
  if (!updateUser) {
    throw new AppError(
      httpStatus.INTERNAL_SERVER_ERROR,
      "Something went wrong . Please again resend the code after a few second"
    );
  }
  sendEmail({
    email: user.email,
    subject: "Activate Your Account",
    html: registrationSuccessEmailBody(user.fullName, updateUser.verifyCode),
  });
  return null;
};

const getMyProfile = async (userData: JwtPayload) => {
  const result = await User.findOne({ email: userData.email })
    .select("-password +blockedUsers")
    .populate("expertise", "_id name icon");

  if (!result) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  return result;
};

type TUpdateProfilePayload = Omit<
  Partial<TUser>,
  'profession' | 'governingBody' | 'expertise'
> & {
  profession?: string;
  governingBody?: string;
  expertise?: string[] | string;
};

const updateProfile = async (
  id: string,
  imageUrl: string | undefined,
  payload: TUpdateProfilePayload
) => {
  // lean() avoids hydrating legacy string values in fields that are now
  // ObjectIds. Those unrelated values must not block a partial profile update.
  const user = await User.findById(id)
    .select('profession governingBody location')
    .lean();
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  const professionId = String(payload.profession ?? user.profession);
  const governingBodyId = String(payload.governingBody ?? user.governingBody);

  if (payload.profession) {
    const profession = await Profession.findById(payload.profession);
    if (!profession) {
      throw new AppError(httpStatus.NOT_FOUND, "Profession not found");
    }
  }

  if (payload.profession || payload.governingBody) {
    await GoverningBodyServices.validateGoverningBodyInProfession(
      governingBodyId,
      professionId
    );
  }

  const updateData: Record<string, unknown> = {};

  const allowedFields = [
    'fullName',
    'profession',
    'licenseNo',
    'governingBody',
    'phone',
    'bio',
    'country',
    'province',
    'city',
  ] as const;

  for (const field of allowedFields) {
    if (payload[field] !== undefined) {
      updateData[field] = payload[field];
    }
  }

  // Handle expertise ObjectIds from dropdown
  if (payload.expertise !== undefined) {
    const rawExpertise = Array.isArray(payload.expertise)
      ? payload.expertise
      : [payload.expertise];

    const validExpertiseIds = rawExpertise
      .filter((expId) => typeof expId === 'string' && Types.ObjectId.isValid(expId))
      .map((expId) => new Types.ObjectId(expId));

    updateData.expertise = validExpertiseIds;

    // Sync User's Expertise collection documents for user
    if (validExpertiseIds.length > 0) {
      const adminExpertises = await Expertise.find({
        _id: { $in: validExpertiseIds },
      });

      for (const adminExp of adminExpertises) {
        const existing = await Expertise.findOne({
          user: new Types.ObjectId(id),
          name: { $regex: `^${adminExp.name.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}$`, $options: 'i' },
        });
        if (!existing) {
          await Expertise.create({
            user: new Types.ObjectId(id),
            name: adminExp.name,
            icon: adminExp.icon,
          });
        }
      }
    }
  }

  // Use dot notation so a partial location update does not replace the other
  // nested location values.
  if (payload.location) {
    if (payload.location.address !== undefined) {
      updateData['location.address'] = payload.location.address;
    }
    if (payload.location.coordinates !== undefined) {
      updateData['location.coordinates'] = payload.location.coordinates;
    }
    if (payload.location.radiusInKm !== undefined) {
      updateData['location.radiusInKm'] = payload.location.radiusInKm;
    }
  }

  if (imageUrl) {
    updateData.profileImage = imageUrl;
  }

  if (Object.keys(updateData).length === 0) {
    throw new AppError(httpStatus.BAD_REQUEST, 'No profile data provided');
  }

  const result = await User.findByIdAndUpdate(
    id,
    { $set: updateData },
    { new: true, runValidators: true }
  )
    .populate('expertise', '_id name icon')
    .select('-password')
    .lean();

  if (!result) {
    throw new AppError(httpStatus.NOT_FOUND, 'User not found');
  }

  // Keep author's consultations in sync with their updated profile location
  const consultLocationUpdate: Record<string, unknown> = {};
  if (updateData.country !== undefined) consultLocationUpdate.country = updateData.country;
  if (updateData.province !== undefined) consultLocationUpdate.province = updateData.province;
  if (updateData.city !== undefined) consultLocationUpdate.city = updateData.city;
  if (updateData['location.coordinates'] !== undefined) {
    consultLocationUpdate['location.coordinates'] = updateData['location.coordinates'];
  }
  if (Object.keys(consultLocationUpdate).length > 0) {
    await Consult.updateMany({ author: new Types.ObjectId(id) }, { $set: consultLocationUpdate });
  }

  return result;
};

const blockUser = async (
  currentUserId: string,
  targetUserId: string,
  currentUserRole: TUserRole
) => {
  if (!Types.ObjectId.isValid(targetUserId)) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      "Invalid user ID. Send the user's _id in the URL."
    );
  }

  if (currentUserId === targetUserId) {
    throw new AppError(httpStatus.BAD_REQUEST, "You cannot block yourself");
  }

  const targetUser = await User.exists({ _id: targetUserId, isDeleted: false });
  if (!targetUser) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found!");
  }

  if (currentUserRole === 'admin') {
    const updatedTarget = await User.findOneAndUpdate(
      { _id: targetUserId, isDeleted: false },
      [{ $set: { isBlocked: { $not: ['$isBlocked'] } } }],
      { new: true }
    ).select('_id isBlocked');

    if (!updatedTarget) {
      throw new AppError(httpStatus.NOT_FOUND, "User not found!");
    }

    return {
      userId: targetUserId,
      blocked: updatedTarget.isBlocked,
      blockType: 'account' as const,
    };
  }

  const currentUser = await User.findById(currentUserId).select('+blockedUsers');
  if (!currentUser) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found!");
  }

  const blocked = (currentUser.blockedUsers || []).some(
    (blockedUserId) => blockedUserId.toString() === targetUserId
  );

  await User.findByIdAndUpdate(
    currentUserId,
    blocked
      ? { $pull: { blockedUsers: new Types.ObjectId(targetUserId) } }
      : { $addToSet: { blockedUsers: new Types.ObjectId(targetUserId) } }
  );

  return {
    userId: targetUserId,
    blocked: !blocked,
    blockType: 'user-to-user' as const,
  };
};

const getSingleUser = async (id: string, currentUserId: string) => {
  if (!Types.ObjectId.isValid(id)) {
    throw new AppError(httpStatus.BAD_REQUEST, "Invalid user ID");
  }

  const [user, currentUser] = await Promise.all([
    User.findById(id)
      .select('-password -blockedUsers')
      .populate('expertise', '_id name icon')
      .lean(),
    User.findById(currentUserId).select('+blockedUsers').lean(),
  ]);
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  // Log the profile view (non-blocking)
  ProfileViewServices.logProfileView(currentUserId, id);

  const blocked = (currentUser?.blockedUsers || []).some(
    (blockedUserId) => blockedUserId.toString() === id
  );

  // Some legacy users store names (for example "Doctor") in fields that are
  // now ObjectId references. Populate only valid IDs so those profiles remain
  // readable while preserving their legacy string values.
  const professionId = String(user.profession || '');
  const governingBodyId = String(user.governingBody || '');
  const [profession, governingBody] = await Promise.all([
    Types.ObjectId.isValid(professionId)
      ? Profession.findById(professionId).select('_id name').lean()
      : null,
    Types.ObjectId.isValid(governingBodyId)
      ? GoverningBody.findById(governingBodyId).select('_id name').lean()
      : null,
  ]);

  return {
    ...user,
    profession: Types.ObjectId.isValid(professionId) ? profession : user.profession,
    governingBody: Types.ObjectId.isValid(governingBodyId)
      ? governingBody
      : user.governingBody,
    blocked,
  };
};

const getAllUser = async (query: Record<string, unknown>) => {
  const normalUserQuery = new QueryBuilder(User.find(), query)
    .search(["fullName"])
    .fields()
    .filter()
    .paginate()
    .sort();

  const meta = await normalUserQuery.countTotal();
  const users = await normalUserQuery.modelQuery;

  const result = await Promise.all(
    users.map(async (user: TUser) => {
      return user;
    })
  );

  return {
    meta,
    result,
  };
};

const getReferralUsers = async (
  userId: string,
  matchField: "follower" | "following",
  lookupField: "follower" | "following",
  professionName?: string,
  expertiseName?: string,
  targetExpertiseId?: string,
  query?: Record<string, unknown>
) => {
  const user = await User.exists({ _id: userId });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  const pipeline: PipelineStage[] = [
    {
      $match: {
        [matchField]: new Types.ObjectId(userId),
      },
    },
    {
      $sort: {
        createdAt: -1,
      },
    },
    {
      $lookup: {
        from: "users",
        localField: lookupField,
        foreignField: "_id",
        as: "user",
      },
    },
    {
      $unwind: "$user",
    },
    {
      $match: {
        "user.isDeleted": { $ne: true },
      },
    },
    {
      $lookup: {
        from: "professions",
        localField: "user.profession",
        foreignField: "_id",
        as: "professionDetails",
      },
    },
    {
      $lookup: {
        from: "expertises",
        let: { userId: "$user._id", userExp: "$user.expertise" },
        pipeline: [
          {
            $match: {
              $expr: {
                $or: [
                  { $in: ["$_id", { $ifNull: ["$$userExp", []] }] },
                  { $eq: ["$user", "$$userId"] },
                ],
              },
            },
          },
        ],
        as: "expertiseDetails",
      },
    },
  ];

  const effectiveProfession =
    professionName ||
    (typeof query?.professionName === "string"
      ? query.professionName
      : typeof query?.profession === "string"
        ? query.profession
        : undefined);

  const normalizedProfession = effectiveProfession?.trim();
  if (
    normalizedProfession &&
    normalizedProfession.toLowerCase() !== "all"
  ) {
    const escapedProfession = normalizedProfession.replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );

    pipeline.push({
      $match: {
        $or: [
          {
            "professionDetails.name": {
              $regex: `^${escapedProfession}$`,
              $options: "i",
            },
          },
          {
            "user.profession": {
              $regex: `^${escapedProfession}$`,
              $options: "i",
            },
          },
        ],
      },
    });
  }

  const effectiveExpertise =
    expertiseName ||
    (typeof query?.expertiseName === "string"
      ? query.expertiseName
      : typeof query?.expertise === "string"
        ? query.expertise
        : undefined);

  const effectiveTargetExpertiseId =
    targetExpertiseId ||
    (typeof query?.targetExpertiseId === "string"
      ? query.targetExpertiseId
      : typeof query?.expertiseId === "string"
        ? query.expertiseId
        : undefined);

  const normalizedExpertise = effectiveExpertise?.trim();
  if (normalizedExpertise && normalizedExpertise.toLowerCase() !== "all") {
    const escapedExpertise = normalizedExpertise.replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );

    const matchCriteria: any[] = [
      {
        "expertiseDetails.name": {
          $regex: `^${escapedExpertise}$`,
          $options: "i",
        },
      },
    ];

    if (effectiveTargetExpertiseId && Types.ObjectId.isValid(effectiveTargetExpertiseId)) {
      matchCriteria.push({
        "expertiseDetails._id": new Types.ObjectId(effectiveTargetExpertiseId),
      });
      matchCriteria.push({
        "user.expertise": new Types.ObjectId(effectiveTargetExpertiseId),
      });
    }

    pipeline.push({
      $match: {
        $or: matchCriteria,
      },
    });
  }

  const rawSearchTerm =
    typeof query?.searchTerm === "string"
      ? query.searchTerm.trim()
      : typeof query?.search === "string"
        ? query.search.trim()
        : "";

  if (rawSearchTerm) {
    const escapedSearch = rawSearchTerm.replace(
      /[.*+?^${}()|[\]\\]/g,
      "\\$&"
    );
    const searchRegex = new RegExp(escapedSearch, "i");

    pipeline.push({
      $match: {
        $or: [
          { "user.fullName": searchRegex },
          { "user.email": searchRegex },
          { "user.city": searchRegex },
          { "user.country": searchRegex },
          { "professionDetails.name": searchRegex },
          { "user.profession": searchRegex },
        ],
      },
    });
  }

  pipeline.push({
    $project: referralUserProjection,
  });

  return Follow.aggregate(pipeline);
};

const getMyReferralNetwork = async (
  userId: string,
  query: Record<string, unknown>
) => {
  console.log("referral query:", query);
  const user = await User.exists({ _id: userId });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User not found");
  }

  const adminIds = await User.find({ role: "admin", isDeleted: false }).distinct(
    "_id"
  );
  const filters = await Expertise.find({ user: { $in: adminIds } })
    .select("_id name")
    .sort({ name: 1 })
    .collation({ locale: "en", strength: 2 })
    .lean();

  const expertiseId =
    typeof query.expertiseId === "string" ? query.expertiseId.trim() : "";
  if (expertiseId && !Types.ObjectId.isValid(expertiseId)) {
    throw new AppError(httpStatus.BAD_REQUEST, "Invalid expertiseId");
  }

  const followingIds = await Follow.find({
    follower: new Types.ObjectId(userId),
  }).distinct("following");

  const userQuery = new QueryBuilder(
    User.find({
      _id: { $in: followingIds },
      isDeleted: { $ne: true },
      ...(expertiseId ? { expertise: new Types.ObjectId(expertiseId) } : {}),
    })
      .populate({ path: "profession", select: "name" })
      .populate({ path: "governingBody", select: "name" })
      .populate({ path: "expertise", select: "_id name icon" })
      .select(
        "fullName email profileImage profession licenseNo governingBody phone bio country city location isPremium expertise"
      ) as any,
    query
  ).search(["fullName", "email"]);

  const users = await userQuery.modelQuery;

  const result = users.map((item: any) => {
    const userObj = typeof item.toObject === "function" ? item.toObject() : item;

    return {
      _id: userObj._id,
      fullName: userObj.fullName,
      email: userObj.email,
      profileImage: userObj.profileImage,
      profession:
        userObj.profession && typeof userObj.profession === "object"
          ? userObj.profession.name
          : userObj.profession,
      licenseNo: userObj.licenseNo,
      governingBody:
        userObj.governingBody && typeof userObj.governingBody === "object"
          ? userObj.governingBody.name
          : userObj.governingBody,
      phone: userObj.phone,
      bio: userObj.bio,
      country: userObj.country,
      city: userObj.city,
      location: userObj.location,
      isPremium: userObj.isPremium,
      expertise: Array.isArray(userObj.expertise)
        ? userObj.expertise.map((expertiseItem: any) => ({
          _id: expertiseItem._id,
          name: expertiseItem.name,
          icon: expertiseItem.icon,
        }))
        : [],
    };
  });

  return {
    filters,
    result,
  };
};

const getAddedMeToReferralNetwork = async (
  userId: string,
  query: Record<string, unknown> = {}
) => {
  return getReferralUsers(
    userId,
    "following",
    "follower",
    undefined,
    undefined,
    undefined,
    query
  );
};

const addToReferralNetwork = async (userId: string, targetUserId: string) => {
  if (userId === targetUserId) {
    throw new AppError(httpStatus.BAD_REQUEST, "You cannot add yourself to your referral network");
  }

  const targetUser = await User.exists({ _id: targetUserId, isDeleted: false });
  if (!targetUser) {
    throw new AppError(httpStatus.NOT_FOUND, "Target user not found");
  }

  await assertUsersCanInteract(userId, targetUserId);

  // Upsert: insert only if not already exists
  await Follow.updateOne(
    {
      follower: new Types.ObjectId(userId),
      following: new Types.ObjectId(targetUserId),
    },
    {
      $setOnInsert: {
        follower: new Types.ObjectId(userId),
        following: new Types.ObjectId(targetUserId),
      },
    },
    { upsert: true }
  );

  return { message: "User added to your referral network successfully" };
};

const removeFromMyReferralNetwork = async (
  userId: string,
  targetUserId: string
) => {
  if (!Types.ObjectId.isValid(targetUserId)) {
    throw new AppError(httpStatus.BAD_REQUEST, "Invalid target user ID");
  }

  const result = await Follow.deleteOne({
    follower: new Types.ObjectId(userId),
    following: new Types.ObjectId(targetUserId),
  });

  if (!result.deletedCount) {
    throw new AppError(
      httpStatus.NOT_FOUND,
      "User is not in your referral network"
    );
  }

  return { userId: targetUserId, removed: true };
};

const getBrowsableUsersForReferral = async (
  userId: string,
  query: Record<string, unknown>
) => {
  const { search, profession, page = 1, limit = 20 } = query;

  const filter: Record<string, unknown> = {
    _id: { $ne: new Types.ObjectId(userId) },
    isDeleted: false,
    isVerified: true,
    isActive: true,
  };

  if (search) {
    filter.$or = [
      { fullName: { $regex: search, $options: 'i' } },
      { city: { $regex: search, $options: 'i' } },
      { country: { $regex: search, $options: 'i' } },
    ];
  }

  if (profession) {
    filter.profession = { $regex: profession, $options: 'i' };
  }

  const skip = (Number(page) - 1) * Number(limit);
  const total = await User.countDocuments(filter);

  const users = await User.find(filter)
    .select('fullName profileImage profession licenseNo governingBody bio city country isPremium')
    .skip(skip)
    .limit(Number(limit))
    .sort({ createdAt: -1 });

  return {
    meta: {
      total,
      page: Number(page),
      limit: Number(limit),
      totalPage: Math.ceil(total / Number(limit)),
    },
    result: users,
  };
};

const registerDevice = async (userId: string, playerId: string) => {
  const playerIds = await registerPushSubscription(userId, playerId);

  if (!playerIds) {
    throw new AppError(httpStatus.BAD_REQUEST, "Invalid device id");
  }

  return { playerIds };
};

const unregisterDevice = async (userId: string, playerId: string) => {
  const playerIds = await unregisterPushSubscription(userId, playerId);

  if (!playerIds) {
    throw new AppError(httpStatus.BAD_REQUEST, "Invalid device id");
  }

  return { playerIds };
};

export const UserServices = {
  createUserIntoDB,
  getMyProfile,
  resendVerifyCode,
  verifyCode,
  updateProfile,
  blockUser,
  getSingleUser,
  getAllUser,
  getMyReferralNetwork,
  getAddedMeToReferralNetwork,
  addToReferralNetwork,
  removeFromMyReferralNetwork,
  getBrowsableUsersForReferral,
  registerDevice,
  unregisterDevice,
};
