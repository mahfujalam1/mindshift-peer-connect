
import config from "../../config";
import bcrypt from 'bcrypt';
import sendEmail from "../../utilities/sendEmail";
import resetPasswordEmailBody from "../../mailTemplate/resetPasswordEmailBody";
import User from "../user/user-model";
import AppError from "../../error/appError";
import httpStatus from "http-status";
import { TUserRole } from "../user/user-interface";
import { createToken } from "../user/user.utils";
import { TLogin } from "./auth-interface";
import { JwtPayload } from "jsonwebtoken";
import registrationSuccessEmailBody from "../../mailTemplate/registerSucessEmail";
import { registerPushSubscription } from "../../helper/pushSubscription";

const generateVerifyCode = (): number => {
  return Math.floor(100000 + Math.random() * 900000);
};

const logInUserIntoDB = async (payload: TLogin & { playerId?: string }) => {
  // Find the user by email
  const user = await User.findOne({ email: payload.email });

  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }

  if (user.isDeleted) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is already deleted');
  }

  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'Right now this user is blocked. Contact support for assistance');
  }

  // Check if the provided password matches the stored hashed password
  if (!(await User.isPasswordMatched(payload?.password, user?.password))) {
    throw new AppError(httpStatus.FORBIDDEN, 'Password does not match');
  }

  // Registered before the unverified early return, so a device is not lost
  // when the account still has to be activated.
  await registerPushSubscription(String(user._id), payload.playerId);

  // Email not verified yet
  if (!user.isActive && !user.isVerified) {
    const verifyCode = generateVerifyCode();
    await User.findByIdAndUpdate(user._id, { verifyCode: verifyCode, codeExpireIn: new Date(Date.now() + 5 * 60000) });

    sendEmail({
      email: payload.email,
      subject: 'Activate Your Account',
      html: registrationSuccessEmailBody(user.fullName, verifyCode),
    });

    return { email_verification: false };
  }

  // Email verified, waiting for admin approval
  if (!user.isVerified) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'Waiting for admin approval. You will be notified once your account is approved.'
    );
  }

  // Admin deactivated the account
  if (!user.isActive) {
    throw new AppError(httpStatus.FORBIDDEN, 'Your account has been deactivated. Please contact support for assistance.');
  }

  // Create the JWT payload for generating tokens
  const jwtPayload = {
    id: String(user._id),
    email: user.email,
    role: user.role as TUserRole,
  };

  // Create access and refresh tokens
  const accessToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );
  const refreshToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );

  return {
    id: user._id,
    accessToken,
    refreshToken,
  };
};




const changePasswordIntoDB = async (
  userData: JwtPayload,
  payload: {
    oldPassword: string;
    newPassword: string;
    confirmNewPassword: string;
  }
) => {
  if (payload.newPassword !== payload.confirmNewPassword) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      "Password and confirm password doesn't match"
    );
  }

  const user = await User.findById(userData.id);
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  // Debugging: Log password comparison
  console.log('Comparing Passwords...');
  console.log('Old Password (Plain):', payload.oldPassword);
  console.log('Stored Password Hash:', user.password);

  const isMatched = await User.isPasswordMatched(payload.oldPassword, user.password);

  if (!isMatched) {
    throw new AppError(httpStatus.FORBIDDEN, 'Password does not match');
  }

  // Update the user's password and let the pre-save hook handle hashing
  user.password = payload.newPassword;
  user.passwordChangedAt = new Date();
  await user.save();

  // Create new tokens
  const jwtPayload = {
    id: String(user._id),
    email: user.email,
    role: user.role as TUserRole,
  };

  const accessToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );
  const refreshToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );

  return {
    accessToken,
    refreshToken,
  };
};



// forgot password
const forgetPassword = async (email: string) => {
  const user = await User.findOne({ email: email });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  const resetCode = generateVerifyCode();
  await User.findOneAndUpdate(
    { email: email },
    {
      resetCode: resetCode,
      isResetVerified: false,
      codeExpireIn: new Date(Date.now() + 15 * 60000),
    }
  );

  sendEmail({
    email: user.email,
    subject: 'Reset password code',
    html: resetPasswordEmailBody('Hello', resetCode),
  });

  return null;
};


const verifyResetOtp = async (email: string, resetCode: number) => {
  const user = await User.findOne({ email: email });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  if (user.codeExpireIn < new Date(Date.now())) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Reset code is expire');
  }
  if (user.resetCode !== Number(resetCode)) {
    throw new AppError(httpStatus.BAD_REQUEST, 'Reset code is invalid');
  }
  await User.findOneAndUpdate(
    { email: email },
    { isResetVerified: true },
    { new: true, runValidators: true }
  );
  return null;
};

// reset password
const resetPassword = async (payload: {
  email: string;
  password: string;
  confirmPassword: string;
}) => {
  if (payload.password !== payload.confirmPassword) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      "Password and confirm password doesn't match"
    );
  }
  // Only load fields required by the reset flow. Some legacy users may still
  // have string values in profile fields that are now stored as ObjectIds;
  // hydrating and saving the full document would revalidate those unrelated
  // fields and prevent the password from being reset.
  const user = await User.findOne({ email: payload.email }).select(
    '_id email role isResetVerified isDeleted isBlocked'
  );
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (!user.isResetVerified) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      'You need to verify reset code before reset password'
    );
  }

  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  const passwordChangedAt = new Date();
  const hashedPassword = await bcrypt.hash(
    payload.password,
    Number(config.bcrypt_salt_rounds)
  );

  // Use a targeted update instead of document.save(), which validates every
  // hydrated field. Keeping isResetVerified in the filter also makes the
  // one-time reset authorization atomic.
  const updateResult = await User.updateOne(
    { _id: user._id, isResetVerified: true },
    {
      $set: {
        password: hashedPassword,
        passwordChangedAt,
        isResetVerified: false,
      },
      $unset: { resetCode: 1, codeExpireIn: 1 },
    }
  );

  if (updateResult.modifiedCount !== 1) {
    throw new AppError(
      httpStatus.BAD_REQUEST,
      'Password reset authorization is no longer valid'
    );
  }
  const jwtPayload = {
    id: String(user!._id),
    email: user!.email,
    role: user!.role as TUserRole,
  };
  const accessToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );
  const refreshToken = createToken(
    jwtPayload,
    config.jwt_access_screet as string,
    config.jwt_access_expires_in
  );

  return { accessToken, refreshToken };
};

const resendResetCode = async (email: string) => {
  const user = await User.findOne({ email: email });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  const resetCode = generateVerifyCode();
  await User.findOneAndUpdate(
    { email: email },
    {
      resetCode: resetCode,
      isResetVerified: false,
      codeExpireIn: new Date(Date.now() + 15 * 60000),
    }
  );
  sendEmail({
    email: user.email,
    subject: 'Reset password code',
    html: resetPasswordEmailBody('Hello', resetCode),
  });

  return null;
};


const resendVerifyCode = async (email: string) => {
  const user = await User.findOne({ email: email });
  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, 'This user does not exist');
  }
  if (user.isDeleted) {
    throw new AppError(
      httpStatus.FORBIDDEN,
      'This user is already deleted'
    );
  }
  if (user.isBlocked) {
    throw new AppError(httpStatus.FORBIDDEN, 'This user is blocked');
  }

  const verifyCode = generateVerifyCode();
  await User.findOneAndUpdate(
    { email: email },
    {
      verifyCode: verifyCode,
      isVerified: false,
      codeExpireIn: new Date(Date.now() + 5 * 60000),
    }
  );
  sendEmail({
    email: user.email,
    subject: 'Reset password code',
    html: resetPasswordEmailBody('Hello', verifyCode),
  });

  return null;
};


const deleteUser = async (userId: string, password?: string) => {
  const user = await User.findById(userId);

  if (!user) {
    throw new AppError(httpStatus.NOT_FOUND, "User Not Found!");
  }

  if (user.role === 'user') {
    if (!password) {
      throw new AppError(httpStatus.BAD_REQUEST, "Password is required");
    }

    const isPasswordMatched = await User.isPasswordMatched(
      password,
      user.password
    );

    if (!isPasswordMatched) {
      throw new AppError(httpStatus.UNAUTHORIZED, "Password does not match");
    }
  }

  const result = await User.findByIdAndDelete(userId);

  if (!result) {
    throw new AppError(httpStatus.INTERNAL_SERVER_ERROR, "Failed to delete user.");
  }

  return { userId, deleted: true };
};

export const AuthServices = {
  logInUserIntoDB,
  forgetPassword,
  resendResetCode,
  resendVerifyCode,
  resetPassword,
  verifyResetOtp,
  changePasswordIntoDB,
  deleteUser
};
