import { Schema, model } from 'mongoose';
import { TCoffeeConnect } from './coffee-connect.interface';

const coffeeConnectSchema = new Schema<TCoffeeConnect>(
  {
    title: { type: String, required: true },
    description: { type: String, required: true },
    image: { type: String, required: true },
    date: { type: String, required: true },
    startTime: { type: String, required: true },
    endTime: { type: String, required: true },
    timezone: { type: String, required: true },
    startAt: { type: Date, required: true, index: true },
    endAt: { type: Date, required: true, index: true },
    zoomMeetingId: { type: String },
    zoomMeetingPassword: { type: String },
    zoomJoinUrl: { type: String },
    zoomStartUrl: { type: String },
    status:{
      type: String,
      enum: ["Accepted" , "Rejected", "Pending"],
      default: "Pending"
    },
    maxParticipants: { type: Number, default: 15 },
    participants: [{ type: Schema.Types.ObjectId, ref: 'User' }], 
    isExpired: { type: Boolean, default: false },
    isDeleted: { type: Boolean, default: false },
    notified2h: { type: Boolean, default: false },
    notified10m: { type: Boolean, default: false },
  },
  {
    timestamps: true,
  }
);

export const CoffeeConnect = model<TCoffeeConnect>('CoffeeConnect', coffeeConnectSchema);
