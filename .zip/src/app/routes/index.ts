import { Router } from 'express';
import { UserRoutes } from '../modules/user/user-route';
import { AuthRoutes } from '../modules/auth/auth-route';
import { ManageRoutes } from '../modules/manage-web/manage.routes';
import { notificationRoutes } from '../modules/notification/notification.routes';
import { metaRoutes } from '../modules/meta/meta.routes';
import { InvoiceRoutes } from '../modules/invoice/invoice.route';
import { ConsultRoutes } from '../modules/consult/consult.route';
import { ChatRoutes, ChatSettingsRoutes } from '../modules/chat/chat.route';
import { ChatAssetRoutes } from '../modules/chat-asset/chat-asset.route';
import { ExpertiseRoutes } from '../modules/expertise/expertise.route';
import { CallRoutes, CallSettingsRoutes } from '../modules/call/call.route';
import { CoffeeConnectRoutes } from '../modules/coffee-connect/coffee-connect.route';
import { LunchAndLearnRoutes } from '../modules/lunch-and-learn/lunch-and-learn.route';
import { SocialEventRoutes } from '../modules/social-event/social-event.route';
import { ReportRoutes } from '../modules/report/report.route';
import { LiveDiscussionRoutes } from '../modules/live-discussion/live-discussion.route';
import { EventRoutes } from '../modules/event/event.route';
import { ProfessionRoutes } from '../modules/profession/profession.route';
import { GoverningBodyRoutes } from '../modules/governingBody/governingBody.route';
import { DashboardRoutes } from '../modules/dashboard/dashboard.route';
import { CustomerSupportRoutes } from '../modules/customer-support/customer-support.route';
import { UploadRoutes } from '../modules/upload/upload.route';
import { ProfileViewRoutes } from '../modules/profile-view/profile-view.route';
import { AppVersionRoutes } from '../modules/app-version/app-version.route';

const router = Router();

const settingsRouter = Router();
settingsRouter.use(CallSettingsRoutes);
settingsRouter.use(ChatSettingsRoutes);

const moduleRoutes = [
  {
    path: '/user',
    route: UserRoutes,
  },
  {
    path: '/auth',
    route: AuthRoutes,
  },
  {
    path: '/upload',
    route: UploadRoutes,
  },
  {
    path: '/profession',
    route: ProfessionRoutes,
  },
  {
    path: '/governing-body',
    route: GoverningBodyRoutes,
  },
  {
    path: '/manage-web',
    route: ManageRoutes,
  },
  {
    path: '/meta',
    route: metaRoutes,
  },
  {
    path: '/notification',
    route: notificationRoutes,
  },
  {
    path: '/invoice',
    route: InvoiceRoutes,
  },
  {
    path: '/consult',
    route: ConsultRoutes,
  },
  {
    path: '/chat',
    route: ChatRoutes,
  },
  {
    path: '/chat-assets',
    route: ChatAssetRoutes,
  },
  {
    path: '/expertise',
    route: ExpertiseRoutes,
  },
  {
    path: '/call',
    route: CallRoutes,
  },
  {
    path: '/settings',
    route: settingsRouter,
  },
  {
    path: '/coffee-connect',
    route: CoffeeConnectRoutes,
  },
  {
    path: '/lunch-and-learn',
    route: LunchAndLearnRoutes,
  },
  {
    path: '/social-event',
    route: SocialEventRoutes,
  },
  {
    path: '/report',
    route: ReportRoutes,
  },
  {
    path: '/live-discussion',
    route: LiveDiscussionRoutes,
  },
  {
    path: '/event',
    route: EventRoutes,
  },
  {
    path: '/dashboard',
    route: DashboardRoutes,
  },
  {
    path: '/customer-support',
    route: CustomerSupportRoutes,
  },
  {
    path: '/profile-view',
    route: ProfileViewRoutes,
  },
  {
    path: '/app-version',
    route: AppVersionRoutes,
  },
];

moduleRoutes.forEach((route) => router.use(route.path, route.route));

export default router;
